<?php

namespace App\Http\Controllers;

use App\Models\Pegawai;
use App\Models\User;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Auth;

class AuthController extends Controller
{
    public function index()
    {
        $adminContact = User::where('role', 'admin')
            ->whereNotNull('nomor_telepon')
            ->where('nomor_telepon', '!=', '')
            ->first();

        // Ambil nomornya saja, jika tidak ada set null
        $nomorAdmin = $adminContact ? $adminContact->nomor_telepon : null;

        return view('pages.auth.login', compact('nomorAdmin'));
    }

    public function login(Request $request)
    {
        // 1. Ubah validasi dari email ke nip
        $request->validate([
            'nip'      => 'required|numeric|digits:18',
            'password' => 'required',
        ], [
            // NIP
            'nip.required' => 'NIP wajib diisi.',
            'nip.numeric'  => 'NIP harus berupa angka.',
            'nip.digits'   => 'NIP harus 18 digit.',

            // Password
            'password.required' => 'Password wajib diisi.',
        ]);


        // 2. Cari Pegawai berdasarkan NIP
        $pegawai = Pegawai::where('nip', $request->nip)->first();

        // 3. Cek apakah Pegawai ada DAN memiliki akun user aktif
        if ($pegawai && $pegawai->user) {

            // 4. Lakukan Auth::attempt menggunakan email dari relasi user tersebut
            // Trik: Kita login pakai email di belakang layar, tapi user taunya pakai NIP
            $credentials = [
                'email' => $pegawai->user->email,
                'password' => $request->password
            ];

            if (Auth::attempt($credentials)) {
                $request->session()->regenerate();

                session()->flash('show_periode_modal', true);

                $role = Auth::user()->role;

                if ($role === 'admin') {
                    return redirect()->intended('admin/dashboard');
                } else {
                    return redirect()->intended('dashboard');
                }
            }
        }

        // Jika Pegawai tidak ditemukan atau Password salah
        return back()->withErrors([
            'nip' => 'NIP atau password salah.',
        ])->onlyInput('nip');
    }

    public function logout(Request $request)
    {
        Auth::logout();
        $request->session()->invalidate();
        $request->session()->regenerateToken();
        return redirect('/login');
    }
}
